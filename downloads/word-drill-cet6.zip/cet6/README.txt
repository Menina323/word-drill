词潮 · CET6 词库文件

文件说明
- cet6.json          5,651 条源数据（含重复词；应用导入时会按 word 去重）
- cet6-unique.json   3,992 个唯一词（已去重，适合直接发送/导入）
- cet6.csv           word,phonetic,definition 格式；音标为空，可在应用内回填
- LICENSE-KyleBing.txt  词库来源的 BSD-3-Clause 许可证

手机导入
1. 打开 https://menina323.github.io/word-drill/
2. 导入词库 → JSON 或 CSV
3. 选择本压缩包里的 cet6.json 或 cet6-unique.json（或 cet6.csv）
4. 导入后如需音标，可在「音标回填」上传 word,phonetic CSV

也可以直接在应用内点「导入 CET6 词库」，无需传文件。

词库来源：KyleBing/english-vocabulary
https://github.com/KyleBing/english-vocabulary
License: BSD-3-Clause
